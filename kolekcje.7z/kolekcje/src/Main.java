import java.util.*;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {

        TreeSet<Integer> icy = new TreeSet<>();
        icy.add(1);
        icy.add(2);
        icy.add(3);
        icy.add(4);
        icy.add(5);
        icy.add(6);
        TreeSet<Integer> szprychen = findElementsInRange(icy, 2, 5);
        System.out.println(szprychen);

        LinkedList<Character> lunaSnow = new LinkedList<>();
        lunaSnow.add('a');
        lunaSnow.add('b');
        lunaSnow.add('b');
        lunaSnow.add('a');
        System.out.println(isPalindrome(lunaSnow));

    }

    public static <T> void printUnique(Collection<T> items){
        Set<T> uniqueElements = new HashSet<>(items);
         for(T item : uniqueElements){
             System.out.println(item);
         }
    }

    public static <T> ArrayList<T> mergeLists(ArrayList<T> list1, ArrayList<T> list2){
        ArrayList<T> result = new ArrayList<>();
        result.addAll(list1);
        result.addAll(list2);
        return result;
    }

    public static <T> void reversePrint(Iterable<T> items){
        ArrayList<T> lista = new ArrayList<>();
        for(T item : items){
            lista.add(item);
        }
        for(int i = lista.size();i>=0;i--){
            System.out.println(lista.get(i-1));
        }

    }

    public static <T extends Comparable<T>> TreeSet<T> findElementsInRange(TreeSet<T> spicy, T lowerBound, T upperBound){
        TreeSet<T> grah = new TreeSet<>();
        for (T icy : spicy) {
            if (icy.compareTo(lowerBound) >= 0 && icy.compareTo(upperBound) <= 0) {
               grah.add(icy);
            }
        }
        return grah;
    }

    public static <T extends Comparable<T>> boolean isPalindrome(LinkedList<T> list){
        LinkedList<T> copy = new LinkedList<>(list);
        copy.reversed();
        if(copy.equals(list)){
            return true;
        }
        else return false;
    }
}