public class KlientIndywidualny extends Klient {
    final int PESEL;

    public KlientIndywidualny(String Imie, String Nazwisko, Adres adres,int PESEL) {
        super(Imie, Nazwisko, adres);
        this.PESEL = PESEL;
    }
}
