public class KlientIndywidualny {

}
