import java.util.HashMap;

public class KoszykZakupowy {
    HashMap<Produkt, Integer> listaProduktow;


    public KoszykZakupowy() {

        this.listaProduktow = new HashMap<>();
    }

    void dodajProdukt(Produkt p) {

    }

    void wyswietlZawartoscKoszyka() {


    }

    double obliczCalkowitaWartosc() {
        return 0;
    }
}
