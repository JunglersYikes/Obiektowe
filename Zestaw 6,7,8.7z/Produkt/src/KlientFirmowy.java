public class KlientFirmowy extends Klient{
     final  String NIP;
    final  String REGON;

    public KlientFirmowy(String Imie, String Nazwisko, Adres adres,String NIP,String Regon) {
        super(Imie, Nazwisko, adres);
        this.REGON = Regon;
        this.NIP= NIP;
    }
}
