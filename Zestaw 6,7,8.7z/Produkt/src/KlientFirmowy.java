public class KlientFirmowy extends Klient{
    final  String NIP;
    final  int REGON;

    public KlientFirmowy(String Imie, String Nazwisko, Adres adres,String NIP,int Regon) {
        super(Imie, Nazwisko, adres);
        this.REGON = Regon;
        this.NIP= NIP;
    }
}
