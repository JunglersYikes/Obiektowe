public class Osoba {
    public String imie;
    public String nazwisko;

}
