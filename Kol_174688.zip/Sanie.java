import java.util.ArrayList;
import java.util.Objects;

public class Sanie {
    private ArrayList<Renifer> lista;

    public void setLista(ArrayList<Renifer> lista) {
        this.lista = lista;
    }

    public ArrayList<Renifer> getLista() {
        return lista;
    }

    public Sanie(ArrayList<Renifer> lista) {
        this.lista = lista;
    }

    public void dodajRenifera(Renifer renifer) {
        getLista().add(renifer);
    }

    public void sumaPredkosci(){
        int suma = 0;
        for (int i=0; i<getLista().size(); i++){
            suma+=getLista().get(i).getPredkosc();
        }
        System.out.println("Suma predkości: "+ suma);
    }

    public Renifer najwolniejszyRenifer(){
        Renifer x = getLista().get(0);
        for (int i=0; i<getLista().size(); i++){
            if(x.getPredkosc()>getLista().get(i).getPredkosc()){
                x = getLista().get(i);
            }
        }
        return x;
    }

    @Override
    public String toString() {
        String x = "";
        for (int i=0; i<getLista().size(); i++){
            x+=" "+getLista().get(i).getImie();
        }
        return x;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sanie sanie = (Sanie) o;
        return Objects.equals(sanie.getLista(), getLista());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getLista());
    }
}
