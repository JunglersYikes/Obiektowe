import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Elf elf1 = new Elf("Dawid",19,"konserwator zabawek");
        Elf elf2 = new Elf("Ania",18,"medyk");
        Elf elf3 = new Elf("Leo",20,"ochorniaż");
        ArrayList<Elf> elfs = new ArrayList<>();
        elfs.add(elf1);
        elfs.add(elf2);
        elfs.add(elf3);
        elf1.przestawsie();
        Fabryka fabryka = new Fabryka(elfs,1,2);
        System.out.println("Imie: " +fabryka.najstarszyPracownika().getImie() + " Wiek: " + fabryka.najstarszyPracownika().getWiek() );

        Renifer renifer1 = new Renifer("Rudolf",5);
        Renifer renifer2 = new Renifer("Hudolf",10);
        Renifer renifer3 = new Renifer("Nudolf",15);
        ArrayList<Renifer> renifers = new ArrayList<>();
        renifers.add(renifer1);
        renifers.add(renifer2);
        Sanie sanie = new Sanie(renifers);
        sanie.dodajRenifera(renifer3);
        sanie.sumaPredkosci();
        System.out.println("Imie: "+sanie.najwolniejszyRenifer().getImie()+" Prędkość: " + sanie.najwolniejszyRenifer().getPredkosc());

        System.out.println(fabryka.toString());
    }
}