import java.util.Objects;

public class Elf {
    private String imie;
    private int wiek;
    private String stanowisko;

    public void setImie(String imie) {
        this.imie = imie;
    }
    public void setWiek(int wiek) {
        if(wiek <= 0) {
            throw new IllegalArgumentException("wiek out of range");
        }
        else {
            this.wiek = wiek;
        }
    }

    public void setStanowisko(String stanowisko) {
        this.stanowisko = stanowisko;
    }

    public String getImie(){
        return imie;
    }

    public int getWiek(){
        return wiek;
    }

    public String getStanowisko(){
        return stanowisko;
    }

    public Elf(String imie, int wiek, String stanowisko) {
        this.imie = imie;
        this.wiek = wiek;
        this.stanowisko = stanowisko;
    }

    public void przestawsie(){
        System.out.println("Cześć, nazywam się "+imie+" mam " + wiek +" lat, a moje stanowisko pracy to " + stanowisko);
    }

    @Override
    public String toString() {
        return "imie: " + imie + ", wiek: " + wiek + ", stanowisko: " + stanowisko;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Elf elf = (Elf) o;
        return Objects.equals(imie,elf.imie) && Objects.equals(wiek,elf.wiek) && Objects.equals(stanowisko,elf.stanowisko);
    }

    @Override
    public int hashCode() {
        return Objects.hash(imie, wiek, stanowisko);
    }
}
