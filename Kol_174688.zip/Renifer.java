import java.util.Objects;

public class Renifer {
    private String imie;
    private int predkosc;

    public void setImie(String imie) {
        this.imie = imie;
    }
    public void setPredkosc(int predkosc) {
        if (predkosc < 0) {
            throw new IllegalArgumentException("Predkosc nie moze byc ujemna");
        }
        else {
            this.predkosc = predkosc;
        }
    }
    public String getImie() {
        return imie;
    }
    public int getPredkosc() {
        return predkosc;
    }

    public Renifer(String imie, int predkosc) {
        setImie(imie);
        setPredkosc(predkosc);
    }

    public void nakarmRenifera(){
        setPredkosc(predkosc+5);
    }

    @Override
    public String toString() {
        return "imie: " + getImie() + ", predkosc: " + getPredkosc();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Renifer renifer = (Renifer) o;
        return Objects.equals(getImie(),renifer.getImie()) && Objects.equals(getPredkosc(),renifer.getPredkosc());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getImie(), getPredkosc());
    }
}
