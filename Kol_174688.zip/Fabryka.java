import java.util.ArrayList;
import java.util.Objects;

public class Fabryka {
    private ArrayList<Elf> lista;
    private double dlGeo;
    private double szGeo;

    public void setLista(ArrayList<Elf> lista) {
        this.lista = lista;
    }
    public void setDlGeo(double dlGeo) {
        if(dlGeo >180 && dlGeo <-180) {
            throw new IllegalArgumentException("Niepoprawny argument");
        }else{
            this.dlGeo = dlGeo;
        }
    }
    public void setSzGeo(double szGeo) {
        if(szGeo >90 && szGeo <-90) {
            throw new IllegalArgumentException("Niepoprawny argument");
        }else{
            this.szGeo = szGeo;
        }
    }

    public ArrayList<Elf> getLista() {
        return lista;
    }
    public double getDlGeo() {
        return dlGeo;
    }
    public double getSzGeo() {
        return szGeo;
    }


    public Fabryka(ArrayList<Elf> lista, double dlGeo, double szGeo) {
        this.lista = lista;
        this.dlGeo = dlGeo;
        this.szGeo = szGeo;
    }

    public void dodajPracownika(Elf elf){
        lista.add(elf);
    }

    public void usunPracownika(Elf elf){
        lista.remove(elf);
    }

    public Elf najstarszyPracownika(){
        Elf x = lista.get(0);
        for (int i=0; i<lista.size(); i++){
            if(x.getWiek()<lista.get(i).getWiek()){
                x = lista.get(i);
            }
        }
        return x;
    }

    @Override
    public String toString() {
        String x = "";
        for (int i=0; i<lista.size(); i++){
            x+=" "+lista.get(i).getImie();
        }
        return x + " Dlugosc: "+ dlGeo +" szerokosc: "+szGeo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Fabryka fabryka = (Fabryka) o;
        return Objects.equals(fabryka.lista, lista) && Objects.equals(fabryka.dlGeo, dlGeo) && Objects.equals(fabryka.szGeo, szGeo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lista, dlGeo, szGeo);
    }
}
