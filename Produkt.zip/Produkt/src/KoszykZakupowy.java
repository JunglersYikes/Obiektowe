import java.util.List;
import java.util.ArrayList;

public class KoszykZakupowy {
    List<Produkt> lista = new ArrayList<Produkt>();

    public KoszykZakupowy(Produkt i){
        if(i.iloscNaMagazynie>0){
            this.lista.add(i);
            i.iloscNaMagazynie -= 1;
            System.out.println("Zawartość koszyka: " + i.nazwa);
        }
        else {
            System.out.println("Brak produktu na magazynie");
        }

    }

    public void dodajProdukt(Produkt i){
        if(i.iloscNaMagazynie>0){
            this.lista.add(i);
            i.iloscNaMagazynie -= 1;
        }
        else {
            System.out.println("Brak produktu na magazynie");
        }
    }

    public void wyswietlZawartoscKoszyka(){
        System.out.println(this.lista);
    }

    public double obliczCalkowitaWartosc(){
        double suma = 0;
        for (int i=0; i<this.lista.size(); i++){
            suma+=(lista.get(i).cena);
        }
        return suma;
    }
}
