public class Main{
    public static void main(String[] args) {

        Produkt produkt = new Produkt("Jajka",15,100);
        produkt.wyswietlInformacje();
        produkt.dodajDoMagazynu(10);
        produkt.usunZMagazynu(50);

        KoszykZakupowy koszyk = new KoszykZakupowy(produkt);

    }
}