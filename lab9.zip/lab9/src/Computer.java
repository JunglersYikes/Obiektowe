import java.util.Objects;
public class Computer {
    private String model;
    private String brand;
    private Proccesor proccesor;
    public Computer(String model, String brand, Proccesor proccesor) {
        this.model = model;
        this.brand = brand;
        this.proccesor = proccesor;
    }

    public String getModel() {
        return model;
    }
    public String getBrand() {
        return brand;
    }
    public Proccesor getProccesor() {
        return proccesor;
    }
    public void setProccesor(Proccesor proccesor) {
        this.proccesor = proccesor;
    }

    public void setModel(String model) {
        this.model = model;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Computer that = (Computer) o;
        return Objects.equals(model, that.model) && Objects.equals(brand, that.brand) && Objects.equals(proccesor, that.proccesor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(brand, proccesor, model);
    }

    @Override
    public String toString() {
        return "computer{" +
                "model='" + model + '\'' +
                ", brand='" + brand + '\'' +
                ", proccesor=" + proccesor +
                '}';
    }

}
