public class Main {
    public static void main(String[] args) {
        BookDT0 book = new BookDT0("Wiedźmin: Ostatnie zyczenie","Andrzej Sapkowski",35.99,1993);
        System.out.println(book.title());
        //Person szczypior = new Person("Dawid","Kozłowski",19,new Address("Wosjka Polskiego",3,"78-600","Wałcz"));
        Car samochod = new Car("Fiat","Tipo",5.4);
        System.out.println(samochod.fuelCost(6.30,100));
        Person szczypior = new Person("Dawid",-2);
        System.out.println(szczypior.wiek());
        BankAccount konto = new BankAccount(15345435);
        System.out.println(konto.balance());

    }

}