import java.util.Objects;

public class Proccesor {
    private double frequency;
    private int cores;
    private String manufacturer;
    public Proccesor(double frequency, int cores, String manufacturer) {
        this.frequency = frequency;
        this.cores = cores;
        this.manufacturer = manufacturer;
    }
    public double getFrequency() {
        return frequency;
    }
    public int getCores() {
        return cores;
    }
    public String getManufacturer() {
        return manufacturer;
    }
    public void setFrequency(double frequency) {
        this.frequency = frequency;
    }
    public void setCores(int cores) {
        this.cores = cores;
    }
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Proccesor that = (Proccesor) o;
        return Objects.equals(frequency, that.frequency) && Objects.equals(cores, that.cores) && Objects.equals(manufacturer, that.manufacturer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(frequency, cores, manufacturer);
    }

    @Override
    public String toString() {
        return "Proccesor{" +
                "frequency='" + frequency + '\'' +
                ", cores='" + cores + '\'' +
                ", manufacturer=" + manufacturer +
                '}';
    }
}
