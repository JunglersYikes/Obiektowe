record BookDT0(String title, String author,double price,int yearOfPublication){}
record Address(String street,int houseNumber,String postalCode,String city){}
record Person(String firstName,int wiek){
    public Person(String firstName,int wiek){
        this.firstName = firstName;
        if(wiek <0){
            this.wiek = 0;
        }
        else {
            this.wiek = wiek;
        }
    }
}
record Car(String brand,String model,double fuelConsumptionPer100km){
    public double fuelCost(double fuelPrice, double distance){
        return (((distance/100)*fuelConsumptionPer100km)*fuelPrice);
    }
}
record BankAccount(int accountNumber,double balance){
    public BankAccount(int accountNumber){
        this(accountNumber,0);
    }
}
public class Rekordy {

}
